#response.css("div.name.ellipsis a span::text").extract()
# response.css("div.author span a span::text").extract()
# response.css("div.publisher span a span::text").extract()
# response.css("a.next::attr(href)").extract_first()